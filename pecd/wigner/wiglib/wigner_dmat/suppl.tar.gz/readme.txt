(last modified: January 7, 2015, by N. Tajima)
This folder(directory) contains the Supplemental Material for a paper

     "Analytical expression for precise numerical evaluations
            of the Wigner rotation matrix at high spins"
                          by Naoki Tajima

to be published in Physical Review C.

[1] List of files

1. rmfsc.dat.gz
      An ASCII-code text file which contains the numerical data of the 
      Fourier-series coefficients of the d-function d^{j}_{mk} for 0<=j<=100
      (i.e., j=0, 1/2, 1, 3/2, 2, ..., 99, 199/2, 100)
      compressed with gzip (466 MB).
2. rmfsc50.dat.gz 
      The same as file No.1 but for 0<=j<=50  
      (i.e., j=0, 1/2, 1, 3/2, 2, ..., 49, 99/2, 50) 
      compressed with gzip (24 MB).
      All the data in this file are also included in file No.1. 
      One can use this file instead of file No.1
      when one does not treat angular momenta above 50.
3. basic_set_up_m.f90
       A Fortran90 module containing definitions commonly used by the other
       Fortran90 program files (Nos.4-6)
4. df_main.f90
       A Fortran90 sample program to use the Fourier-series d-function program
5. dffs_m.f90
       A Fortran90 module for the Fourier-series d-function
6. dfwg_m.f90
       A Fortran90 module for the Wigner-formula d-function
7. Makefile
       Input for the "make" command of Unix to compile Fortran90 programs of
       files Nos.3-6.
8. menu1.log
       A sample output (to stdout) log file
       when one does not modify the programs and uses rmfsc.dat (not 
       rmfsc50.dat). See [2].
9. menu2.log
       A sample output (to stdout) log file 
       when one modifies df_main.f90 as "menu=2" and uses rmfsc.dat to create
       rmfsc_binary.dat. See [3].
10. menu3.log
       A sample output (to stdout) log file
       when one modifies df_main.f90 as "menu=3" and uses rmfsc_binary.dat.
       See [3].
11. menu1.j50.log
       A sample output (to stdout) log file like file No.8 but when one
       uses rmfsc50.dat (not rmfsc.dat). See [4].
12. menu2.j50.log
       A sample output (to stdout) log file like file No.9 but when one
       uses rmfsc50.dat (not rmfsc.dat). See [4].
13. menu3.j50.log
       A sample output (to stdout) log file like file No.10 but when one
       used rmfsc50.dat (not rmfsc.dat) to create rmfsc_binary.dat. See [4].
14. readme.txt (this file) 
       An ASCII-code text file which describes how to run the sample programs
       to use the data files.

[2] How to run the programs

To compile the programs, use the Unix command "make", which reads "Makefile".

% make

To create the coefficient data file rmfsc.dat, uncompress rmfsc.dat.gz.

% gunzip rmfsc.dat.gz

To run the created executable file, simply type

% ./a.out

No inputs from the stdin are necessary. 
Outputs are written only to the stdout.

The file No.8 "menu1.log" is an example of the output.
Some of the numbers written to the output may be slightly different for
different computer environments because they represent tiny numerical errors.

[3] How to create a binary data file,
    which enables a much faster execution of the program

It takes 1 minute or so to read rmfsc.dat because it is a text data file.
One can shorten the time to 1 second or so by creating a binary data file
rmfsc_binary.dat and read it instead of the text data file.

To create the binary data file, modify line 13 of df_main.f90
from
    integer,parameter::menu=1
to
    integer,parameter::menu=2

and then

% make
% ./a.out

The file No.9 "menu2.log" is an example of the output.

To use the binary data file, modify line 13 of df_main.f90
to
    integer,parameter::menu=3

and then

% make
% ./a.out

The file No.10 "menu3.log" is an example of the output.

[4] How to use the smaller data file rmfsc50.dat instead of the larger data
    file rmfsc.dat

(1) Uncompress rmfsc50.dat.gz to create rmfsc50.dat.
    % gunzip rmfsc50.dat.gz
(2) Rename rmfsc50.dat as rmfsc.dat.
    % mv rmfsc50.dat rmfsc.dat
(3) Modify line 17 of df_main.f90
    from
        integer,parameter::jmax=200
    to
        integer,parameter::jmax=100
    NB: The variable "jmax" is the maximum angular momentum multiplied by two.

After doing (1)-(3), do the procedures described in [2] and [3].

The file No.11 "menu1.j50.log", the file No.12 "menu2.j50.log", and the file
No.13 "menu3.j50.log" are sample outputs.

It should be noted that, in this version of the program, the returned value
from the Fourier-series d-function is defined to be "2" 
when the necessary coefficients are not available in the data file, i.e., 
for angular momenta above 50 (100) when one uses rmfs50.dat (rmfsc.dat).

[5] Inquiries

e-mail:  tajima@quantum.apphy.u-fukui.ac.jp

The programs and the data files may be modified and redistributed.
